﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRD.UI.Windows.VistaModelo
{
    public class CRD_RolesVistaModelo
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
