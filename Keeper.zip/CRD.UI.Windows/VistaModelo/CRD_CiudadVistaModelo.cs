﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRD.UI.Windows.VistaModelo
{
    public class CRD_CiudadVistaModelo
    {
        public int IdCiudad { get; set; }
        public string NombreCiudad { get; set; }
        public string Descripcion { get; set; }
        public bool Activo { get; set; }
    }
}
